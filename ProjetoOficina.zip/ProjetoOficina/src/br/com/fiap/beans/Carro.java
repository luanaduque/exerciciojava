package br.com.fiap.beans;

public class Carro {

}
